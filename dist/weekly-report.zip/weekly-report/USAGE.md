# Setup

This skill uses the [xSeek CLI](https://www.xseek.io/products/xseek-cli) to pull
real data from your tracked websites — opportunities, brand context, AI bot
crawl logs, GSC metrics, brand mention tracking.

## 1. Install the xSeek CLI

```sh
curl -fsSL https://cli.xseek.io/install.sh | sh
```

## 2. Authenticate

Sign up at [xseek.io](https://www.xseek.io/login) and generate an API key from
Settings → API keys. Then:

```sh
xseek login your_api_key
```

## 3. Verify

```sh
xseek websites
```

You should see the websites tracked under your organization.

## Alternative: xSeek MCP

If you prefer not to install the CLI, you can connect Claude to xSeek directly
via the remote MCP server at `https://www.xseek.io/api/mcp` — claude.ai walks
you through OAuth, no CLI install needed. This skill assumes the CLI is
available; for an MCP-only flow, swap any `xseek <subcommand>` invocation for
the equivalent `mcp__xseek__*` tool call.
