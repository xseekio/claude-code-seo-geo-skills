---
name: generate-article
description: Generate an AI-optimized article from xSeek content gap data and push it to Content Studio. Beats top competitor articles AI currently cites.
argument-hint: [topic]
---

<!-- Generated from the xSeek app repo (skills/). Do not edit here: changes are overwritten on the next publish. -->

# Generate Article — AI-Optimized Article from Opportunity Data

Generate a new article targeting a content gap where your site isn't cited by AI. Analyzes the top-ranking competitor articles that ARE getting cited, studies their structure and content patterns, and writes something better.

**Usage:**
- `/generate-article` — picks the highest-value opportunity automatically
- `/generate-article <topic or query>` — targets a specific topic

The article is pushed to Content Studio as a **draft** via `xseek articles push`. The user can review it in the dashboard, then mark it as ready or published when they're satisfied.

## Steps

### Phase 1: Find the Right Opportunity

**0. If `opportunityId="<uuid>"` was passed in the prompt, use that ID exactly. No fuzzy matching, no "I think the user meant…", no creating a duplicate. Jump straight to step 4 (extract keywords from this exact opportunity row). When you push the article in Phase 4, you MUST pass `--opportunity-id "<the-same-uuid>"` to `xseek articles push`. This is non-negotiable: the dashboard handed you an exact ID, and the only acceptable behavior is to honor it.**

The `opportunityId` is the source of truth for which opportunity this article addresses. Do not call `xseek opportunities` to "find a better match". Skip the discovery, fetch the row, write the article, push it back wired to the same ID.

1. Run `xseek websites --format json` to get the website.

2. Run these in parallel (use `--format json` on all):
   - `xseek opportunities <website> --format json` — pre-computed content gaps with business value
   - `xseek web-searches <website> --pageSize 100 --format json` — LLM search queries
   - `xseek sources <website> --format json` — currently cited URLs
   - `xseek search-queries <website> --pageSize 100 --sortBy impressions --format json` — GSC queries
   - `xseek brand-context <website> --format markdown` — full brand brief (tone, identity, voice, anchors, surface rules, audiences, knowledge, style samples). ALWAYS fetch this — settings can change between runs. Use the rendered markdown as the canonical voice spec for the whole article.

3. If `opportunityId` was passed (step 0), the opportunity row is already chosen — skip this step. Otherwise: if the user provided a topic/query, find the matching opportunity. If neither, pick the highest business-value opportunity (critical > high > medium) with the most frequency.

3b. **Differentiate from existing articles (MANDATORY).** The prompt may include a list titled "This website ALREADY has the following articles (title — primary keyword)". If it doesn't, fetch it yourself: `xseek articles list <website> --format json`. Then enforce all three rules for the article you're about to write:
   - **Distinct angle**: if the opportunity overlaps an existing article's topic, narrow to a specific audience, region, use case or question none of them answers. Never write another variation of an existing piece.
   - **Different primary keyword**: your `--keyword-term` must differ from every existing article's keywords. If your best candidate is taken, use the next-best from the research.
   - **Varied format**: don't default to another "Top N" listicle with the same names. Rotate formats — cost guide, how-to, head-to-head comparison of two options, regional deep-dive, FAQ-led answer page — picking whichever best matches the query intent.

4. Extract **target keywords** from the opportunity's SEO data:
   - `matchedKeyword`: the highest-volume Google keyword mapped to this LLM query
   - `relatedKeywords`: all extracted keywords with their monthly search volume and keyword difficulty (KD)
   - These are real Google keywords people search for — they must be woven into the article's headings, FAQ questions, and body content
   - For branded queries (e.g. "alternatives to Scrunchai"), the related keywords will include branded variants (e.g. "scrunchai alternatives", "scrunchai vs competitors") — use these as-is

5. Present the selected opportunity to the user:
   - The query/topic
   - Business value score
   - How many times AI searched for this
   - Which competitors are getting cited instead
   - The ranking articles (competitor URLs being cited)
   - **Top related keywords** with search volume and KD
   - Ask the user to confirm before proceeding.

### Phase 2: Study the Competition

5. For the top 3-5 ranking articles (competitor URLs that AI cites for this query), fetch each page's content using web fetch.

6. For each competitor article, analyze:
   - **Structure**: H1, H2, H3 hierarchy. How many sections? What topics do they cover?
   - **Length**: Approximate word count
   - **Format**: Do they use tables, lists, FAQs, comparison grids?
   - **Opening**: How do they answer the core query in the first paragraph?
   - **Data**: Do they include statistics, citations, expert quotes?
   - **Schema**: Do they use FAQ, HowTo, or Article schema?
   - **Unique angle**: What's their specific take or positioning?

7. Also find related LLM web searches that cluster around this topic — these become secondary keywords and FAQ questions.

8. Check GSC queries to see if the user's site already ranks for any related terms on Google — these should be woven into the article.

8a. **Merge all keyword sources**: Combine the opportunity's `relatedKeywords` (from step 4), LLM web search clusters (step 7), and GSC queries (step 8) into a single target keyword list. Deduplicate and rank by search volume. The top 5-10 keywords become your primary SEO targets for the article.

### Phase 2b: Validate Product/Competitor Claims

> **The brand brief from step 2 wins.** If it says to promote only the client's own domain (typical B2C / marketplace — e.g. a "surface only our own listings", "never mention competitors", or internal-linking-only rule), **skip this entire phase**: do not fetch, name, link, or recommend any competitor or any entry in the `competitors` list. Send every "where to find / browse / see options" link to the client's OWN pages instead (use the URL patterns in the brand brief). This phase applies only to B2B / product-comparison sites that legitimately reference external products.

8b. **For every product, tool, or company mentioned in the article**, fetch their official website (homepage or pricing page) to verify:
   - **Pricing**: Exact plan names, prices, and billing terms. Never guess pricing — it changes frequently.
   - **Features**: Core feature claims must match what the product actually offers.
   - **Current status**: Is the product still active? Has it been acquired, renamed, or sunset?
   - **Links**: Collect at least one canonical URL per product (homepage, pricing page, or product page) to use as a reference link in the article.

   How to do this:
   - Fetch each product's homepage or pricing page using web fetch
   - If pricing isn't on the homepage, try `/pricing`, `/plans`, or check the page for pricing links
   - If a product website is unreachable or JS-rendered, use web search to find current pricing info
   - Record: product name, URL, pricing summary, key features, last verified date

   **Rules:**
   - Every product mentioned MUST have at least one outbound link to its official website — **UNLESS the brand brief promotes only the client's own domain**, in which case never link or name a competitor; link the client's own pages instead (see the callout above)
   - Never write pricing without fetching the source first — "Free tier available" is acceptable only if confirmed
   - If you can't verify a claim, say "pricing available on their website" with a link instead of guessing
   - Flag any products where fetched data contradicts competitor article claims

### Phase 3: Write the Article

9. **Keyword Research** — once the topic is confirmed, run keyword research:

```sh
xseek keywords <website> "<selected opportunity query>" --format json
```

This returns search volume, keyword difficulty, and related keywords from Google. Use these to:
   - Pick the primary keyword (highest volume, reasonable KD) for the H1 and first paragraph
   - Use top related keywords as H2 headings and FAQ questions
   - Weave medium-tail keywords naturally into the body
   - Avoid keywords with KD > 80 as primary targets unless the site has strong domain authority

**CRITICAL — `--keyword-term` MUST come from this research output, not from your imagination, the article title, or the opportunity query.**

When you push the article in Phase 4, the `--keyword-term` flag must be the exact string of one of the keywords returned by `xseek keywords` above (with a non-zero search volume). Picking a phrase off the title or slug ("which tool best", "tool best optimization") leaves the article linked to a keyword with no volume data, which displays as a broken Target Keywords card on the dashboard.

The right keyword is the one with the highest search volume that semantically matches the article's primary intent. Copy its `keyword` field verbatim. If multiple are tied, prefer the one with lower KD.

**Also pass `--keywords` with the FULL target list.** The article targets a primary keyword plus the secondary terms you placed in H2s, FAQ questions and body copy. Push them all (comma-separated, primary first, max 10) so the dashboard's Target Keywords card shows the real keyword plan instead of a single term. Same rule as `--keyword-term`: every keyword in the list must be a verbatim string from the research output (`xseek keywords`, the opportunity's `relatedKeywords`, or GSC queries) — never invented.

10. **Apply the brand brief** — use every section of the markdown returned by `xseek brand-context` in step 2. Treat it as a single voice spec; missing sections are fine, present sections are non-negotiable.
   - **Tone** (`professional` | `conversational` | `technical` | `friendly`): set the register for the entire article.
   - **Identity → Adjectives**: every paragraph should plausibly fit these words. If the brand says "direct, warm, expert," the article cannot read as "playful, edgy, casual."
   - **Identity → Signature words**: weave them into headings, intros, and CTAs where they fit naturally. Don't shoehorn — but don't ignore them either.
   - **Identity → Banned words**: hard rule. Search the draft for each banned word before output. Zero occurrences allowed.
   - **Identity → Positions** ("what we stand for / what we reject"): these are opinions the brand holds. Reflect them — the article should feel like it could only have come from this brand, not a generic competitor.
   - **Voice → Guidelines**: follow specific writing instructions (sentence length, jargon stance, formality).
   - **Voice → Opening sentence examples**: model the rhythm of the intro paragraph on these.
   - **Anchors → Brands we admire**: borrow the *qualities* of these brands (clarity, opinion, structure) — never copy their words.
   - **Anchors → Voices to avoid**: explicit anti-patterns. If the brand lists "generic SaaS marketing speak," your draft cannot read like that.
   - **Anchors → Own content URLs**: if listed, fetch one of these pages to anchor your prose style on the brand's actual writing.
   - **Surface rules → Always surface**: include the listed claims/numbers/proof points whenever the article context allows.
   - **Surface rules → Never surface**: hard rule. Do not mention any topic, fact, or claim in this list.
   - **Audiences**: each audience has a name + description + topics. Write for the audience whose topics this article best serves; address their language and decision drivers.
   - **Knowledge entries**: weave in company-specific facts, product details, and proprietary expertise. This is information the brand wants highlighted.
   - **Products to recommend**: if the brand brief has a `## Products to recommend` section (a B2C / own-domain catalog), it also lists that client's **filterable fields**. Once you know the article's topic, run `xseek products <website> --<field> <value>` — filtering on whatever fields fit (e.g. `--region charlevoix`, `--capacity 2`, `--make Toyota`) — and recommend **3–8 specific products by name, each linked to its own page**. A specific product beats a generic category page, and it satisfies the own-domain linking rule from Phase 2b. Never invent products that aren't returned by `xseek products`.
   - **Style references (samples)**: match the structure, sentence length, vocabulary level, and personality of these full-length samples. Read them before writing the first paragraph.
   - If no brand brief is set, default to an authoritative, professional tone — but flag this in your output so the user knows the article is generic.

11. Write a new article that:

**Beats the competition by:**
- Covering every subtopic the top 3 articles cover, plus gaps they miss
- Using a better structure (answer-first, more scannable)
- Including more data points and citations
- Adding a FAQ section targeting exact LLM search queries
- Being more direct and less fluffy
- Having verified, accurate pricing and feature data (fetched from source)
- Linking to every product/company mentioned (at least one official URL each)

**Follows these content rules:**

#### Answer-First Format
- The first paragraph must directly answer the core query in 2-3 sentences
- Each H2 section opens with a direct answer before elaboration
- AI models cite the first sentence of a section — make every opener quotable

#### Structure Blueprint
- H1: Contains the primary query naturally (under 60 characters), include the highest-volume related keyword if it fits
- Opening paragraph: Direct answer + one key statistic
- H2 sections: Each covers one clear subtopic. Use related keywords from the opportunity's SEO data as H2/H3 headings where natural
- Comparison table: If the topic involves tools/products/options, include a comparison table — AI models love citing tables
- H3 subsections: Deep dives where needed
- FAQ section: 5-7 questions pulled from LLM web searches, GSC queries, and related keywords. Frame high-volume keywords as questions (e.g. keyword "scrunchai alternatives" → "What are the best Scrunchai alternatives?")
- Each FAQ answer: 2-3 self-contained sentences
- **Sources & References section (MANDATORY, last H2 after the FAQ)**: 3-8 authoritative sources actually used in the article, each as a markdown link with a short note on what it backs (e.g. `- [Statistics Canada — job vacancies Q1 2026](https://...) — vacancy data cited in the intro`). An article with zero verifiable sources does not pass review.
- **Inline source links (MANDATORY)**: every specific statistic, price, study result, date-sensitive fact, or quote from a named person carries an inline markdown link to its source at first mention — readers must be able to click and verify on the spot. DATA links to where the data comes from. Product mentions link to the product's official site — **except when the brand brief promotes only the client's own domain**, in which case product/option mentions link to the client's OWN pages and never to a competitor. This applies to every format (listicle, how-to, cost guide, comparison) — not just product lists.

#### GEO Methods + Human-Like Writing

**Before writing, read the full content of these two skills (installed via `xseek init`):**
- **`/writing-rules`** — human-like writing rules (tone, banned words, sentence structure)
- **`/geo-methods`** — all 9 Princeton GEO methods with examples, domain-specific tips, and pre-publish checklist

Read both skills in full. Every sentence must pass both the human writing check and the GEO optimization check.

#### The four title/description fields

An article carries FOUR of these, not two, and they serve two different
audiences. Writing one and copying it into the others wastes three of them.

| Field | Where it appears | Who reads it | Limit |
| --- | --- | --- | --- |
| `--title` | the H1 on the page | someone already reading | free |
| `--description` | the lede under the H1, and index cards | someone already reading | 1-2 sentences |
| `--meta-title` | the `<title>` tag, browser tab, search result | someone deciding whether to click, or an engine deciding whether to cite | 60 chars |
| `--meta-description` | the search-result snippet | same | 155 chars |

Rules that make them different rather than four spellings of one line:

1. **All four carry the primary keyword.** That is the only thing they share.
2. **The meta title is a REWRITE of the H1, never a copy.** If they are
   identical, the tag is dead weight. The H1 can be curiosity-driven because
   the reader is already there. The meta title has to earn a click against
   nine other results, so it front-loads the keyword and states the payoff.
3. **The lede continues the H1. The meta description does not.** The lede
   assumes the title was just read. The meta description is read alone, in a
   list, so it must stand up with no context.
4. **The meta description promises, it does not summarize.** "This guide
   covers X, Y and Z" describes the article. "Get X in under an hour, with the
   three checks most teams skip" tells the reader what they leave with.
5. **Respect the limits.** Past 60 and 155 characters they are truncated
   mid-word in the result, which reads as carelessness on your page.

Example, same article, four fields:

- title: `Couvreur certifie GAF a Montreal : ce que ca change pour vous`
- description: `Comprendre ce que la certification protege concretement, comment la verifier, et les questions a poser avant de signer.`
- meta-title: `Couvreur certifie GAF Montreal : garanties et verification`
- meta-description: `Ce que la certification GAF Master Contractor couvre vraiment, comment verifier un couvreur en 2 minutes, et les 5 questions a poser avant de signer.`

#### Phase 3b: Add visual context (screenshots)

**Read the `/screenshots` skill in full before this phase.** It holds the only
screenshot rules: how to capture through the xSeek images API (never a browser),
which brands must be attempted, what counts as an unusable capture, and the
`visuals` coverage record you send with the article.

Two things from it that decide whether this phase passed:

1. **Count the named entries first.** Every brand, product, or company the
   article names as an entry gets a capture attempt. All of them, not the ones
   that felt worth it. Article length and mobile readers are not reasons to
   skip.
2. **Report all of them**, including the ones with no image, each with a
   `skipReason`. An unreported skip is indistinguishable from not trying.

### Phase 4: Push to Content Studio

10. **Ask the user** before pushing: "Do you want to push this as a **draft** (review first) or **ready** (ready to publish)?"
   - If the user says draft or doesn't specify → use `--status draft`
   - If the user says ready or publish → use `--status ready`
   - Default to `draft` if unsure

11. Save the article markdown to a temporary file and push it to Content Studio.

   **CRITICAL — the file must contain BODY ONLY:**
   - **NO H1 title** (passed via `--title`)
   - **NO metadata block** (no `**Meta description:**`, `**Target queries:**`, `**Target keywords:**`, `**Recommended schema:**`, `**Estimated word count:**` lines — meta description is passed via `--meta-description`)
   - **NO leading `---` separator**
   - Start the file at the first prose paragraph of the article. Include H2/H3 sections, FAQ, competitive analysis, etc. — everything except the title and the metadata block.

   The metadata block from the Phase 5 output template is for your reasoning/display only — it does NOT belong inside the published article on the live site.

```sh
cat > /tmp/article.md << 'ARTICLE'
[Article BODY only — first prose paragraph, then H2/H3 sections, FAQ, etc.
 NO title, NO metadata block, NO leading `---`.]
ARTICLE

# Push to Content Studio (--status draft or --status ready based on user choice).
# CRITICAL: when `opportunityId` was passed in the original prompt (step 0),
# you MUST include `--opportunity-id "<same-uuid>"` here. The exact same UUID,
# no substitutions. This is what wires the published article back to the
# action plan so the opportunity gets marked done. Skipping it leaves the
# opportunity hanging as "still to ship" and the dashboard will surface
# duplicates.
# Screenshot coverage: ONE entry per brand the article names as an entry,
# including every brand with no capture and the reason. See /screenshots.
cat > /tmp/visuals.json << 'VISUALS'
[
  { "name": "Brand A", "url": "https://brand-a.com", "screenshot": "https://www.xseek.io/images/<id>/brand-a-homepage.jpg" },
  { "name": "Brand B", "url": "https://brand-b.com", "screenshot": null, "skipReason": "capture returned 502 twice" }
]
VISUALS

xseek articles push <website> --title "[H1 title]" --description "[lede, 1-2 sentences]" --meta-title "[<=60 chars]" --meta-description "[<=155 chars]" --status draft --opportunity-id "<uuid-from-prompt>" --keyword-term "[primary keyword]" --keywords "[primary keyword], [secondary 1], [secondary 2], ..." --file /tmp/article.md --visuals /tmp/visuals.json --format json
```

12. Confirm the article was created successfully — display the article ID and status.

13. If the push fails (e.g. auth error), display the error and output the article markdown directly so the user doesn't lose it.

### Phase 5: Output

13. Output the complete article in this format:

```markdown
# [H1 Title — under 60 characters]

**Description (lede):** [1-2 sentences, shown under the H1]
**Meta title:** [under 60 characters, a rewrite of the H1, not a copy]
**Meta description:** [under 155 characters, a promise, includes the primary query]
**Target queries:** [primary LLM query + 3-5 secondary queries]
**Target keywords:** [top 5-10 related keywords from opportunity SEO data, ranked by search volume]
**Recommended schema:** FAQPage, Article
**Estimated word count:** [X words]

---

[Full article content with all H2/H3 sections]

## FAQ

### [Question from LLM web search]?
[2-3 sentence answer — self-contained, quotable]

[5-7 FAQ entries]

---

## Competitive Analysis

| Element | Competitor 1 | Competitor 2 | Competitor 3 | This Article |
|---------|-------------|-------------|-------------|-------------|
| Word count | X | X | X | X |
| Statistics cited | X | X | X | X |
| External sources | X | X | X | X |
| FAQ questions | X | X | X | X |
| Comparison tables | Yes/No | Yes/No | Yes/No | Yes |
| Answer-first format | Yes/No | Yes/No | Yes/No | Yes |

## GEO Scorecard

| Method | Applied | Details |
|--------|---------|---------|
| Cite Sources (+40%) | Yes | X external references |
| Statistics (+37%) | Yes | X data points |
| Quotations (+30%) | Yes | X expert quotes |
| Authoritative Tone (+25%) | Yes | Direct, confident voice |
| Easy-to-Understand (+20%) | Yes | Jargon explained, short paragraphs |
| Technical Terms (+18%) | Yes | X domain terms included |
| Unique Words (+15%) | Yes | Diverse vocabulary |
| Fluency (+15-30%) | Yes | Varied rhythm, natural flow |
| Keyword Stuffing (-10%) | No | Primary keyword used X times |

## Product/Competitor Fact-Check

| Product | Official URL | Pricing Verified | Key Features Confirmed | Notes |
|---------|-------------|-----------------|----------------------|-------|
| [Product] | [URL linked in article] | Yes/No | Yes/No | [Any discrepancies found] |

## Target Keywords Used

| Keyword | Volume/mo | KD | Used In |
|---------|-----------|-----|---------|
| [keyword] | [volume] | [0-100] | H1 / H2 / FAQ / Body |

## LLM Queries Targeted

| Query | Source | Addressed In |
|-------|--------|-------------|
| [query] | LLM web search | Section X / FAQ #Y |
| [query] | GSC | Section X |
```
